<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tbooke</title>
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" >
</head>
<body>

<div class="container">
  <div class="buttons">
    <button class="btn">Join</button>
    <button class="btn">Login</button>
  </div>
  <div class="content">
    <h1>Welcome to Tbooke.net</h1>
    <p class="home-p" >Tbooke.net is more than just a platform,it’s a community where education professionals, institutions and learners share, connect and grow together all while enjoying content that’s educational and entertaining</p>
    <a href="#" class="btn">Learn More</a>
  </div>
</div>

</body>
</html><?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/welcome.blade.php ENDPATH**/ ?>