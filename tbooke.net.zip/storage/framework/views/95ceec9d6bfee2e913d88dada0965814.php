<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
	<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	
	<div class="main">
        <?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
			<main class="content">
				<div class="container-fluid p-0">
					<h1 class="h3 mb-3">Dashboard</h1>
				</div>
				<div class="row">
						<div class="col-6">
							<a class="dashboard-cards-a" href="<?php echo e(route('feed')); ?>">
							  <div class="card">
								<div class="card-header learning">
									<h5 class="card-title mb-3 card-title-dashboard">Tbooke Learning</h5>
									<p>Explore Tbooke Learning, your hub for diverse educational content, interactive lessons, and meaningful connections with learners and educators.</p>
								</div>
							</div>
							</a>
						</div>
						<div class="col-6">
							<div class="card">
								<div class="card-header resources">
									<h5 class="card-title mb-3 card-title-dashboard">Learning Resources</h5>
									<p>Explore Tbooke Learning, your hub for diverse educational content, interactive lessons, and meaningful connections with learners and educators.</p>
								</div>
							</div>
						</div>
				</div>
					<div class="row">
						<div class="col-6">
							<div class="card">
								<div class="card-header schools">
									<h5 class="card-title mb-3 card-title-dashboard">Schools Corner</h5>
									<p>Explore Schools Corner at Tbooke, dedicated pages for educational institutions to create and share content, fostering collaboration and innovation.</p>
								</div>
							</div>
						</div>
						<div class="col-6">
							<div class="card">
								<div class="card-header  blueboard">
									<h5 class="card-title mb-3 card-title-dashboard">Tbooke Blueboard</h5>
									<p>Discover Tbooke's Blueboard, a moderated platform for education-related communications and announcements, connecting educators and learners.</p>
								</div>
							</div>
						</div>
				</div>
			</main>
    
	  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div><?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/dashboard.blade.php ENDPATH**/ ?>