<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="main">
    <?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main class="content">
        <div class="container-fluid p-0">

					<div class="mb-3">
						<div class="row mb-3">
							<div class="col-md-6 d-flex justify-content-start align-items-center">
								<h1 class="h3 d-inline align-middle">Tbooke Learning</h1>
							</div>
						<?php if($userIsCreator): ?>
							<div class="col-md-6 d-flex justify-content-end align-items-center">
								<a type="button" href="<?php echo e(route('tbooke-learning.create')); ?>" class="btn btn-tbooke mb-2 mb-md-0 me-md-2 tbooke-create-btn">Create</a>
							</div> 
						<?php endif; ?>
						</div>
					</div>

						<div class="row content">
							<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-12 col-md-4">
									<div class="card">
										<img class="card-img-top content-thumbnail" src="<?php echo e(asset('storage/' . $content->content_thumbnail)); ?>" alt="">
										<div class="card-header author-category">
											<h5 class="card-title author"><?php echo e($content->user->first_name); ?> <?php echo e($content->user->surname); ?></h5>
											<h5 class="card-title content-title"><?php echo e($content->content_title); ?></h5>
											<div class="content-categories">
												<?php $__currentLoopData = explode(',', $content->content_category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<a href="#" class="badge bg-primary me-1 my-1"><?php echo e($category); ?></a>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
										<div class="card-body tbooke-content">
											<p class="card-text content-desc"><?php echo e(Str::limit(strip_tags($content->content), 66)); ?></p>
											<a href="#" class="card-link read-more-link">Read More</a>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>

		</div>
    </main>
    
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/tbooke-learning.blade.php ENDPATH**/ ?>