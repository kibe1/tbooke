<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main">
			
        	<?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
				<main class="content">
						<!-- Success Modal -->
						<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true"  data-bs-keyboard="true">
							<div class="modal-dialog modal-sm modal-dialog-centered position-absolute end-0">
								<div class="modal-content bg-white">
									<div class="modal-header border-0">
										<h5 class="modal-title text-success" id="successModalLabel">
											Post created successfully
										</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									</div>
								</div>
							</div>
						</div>
						
				<div class="container-fluid p-0">

					<div class="mb-3">
					    <div class="row mb-3">
						  <div class="col-md-12 d-flex justify-content-between align-items-center">
						  		<h1 class="h3 d-inline align-middle">Profile</h1>
								<a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary">Edit Profile</a>
						  </div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-xl-5">
							<div class="card mb-3">
								<div class="card-header">
									<h5 class="card-title mb-0">Profile Details</h5>
								</div>
								<div class="card-body text-center">
										<?php if($user->profile_picture): ?>
											<img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" alt="Profile Picture" alt="Profile Picture" class="img-fluid rounded-circle mb-2" width="128" height="128">
										<?php else: ?>
											<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" alt="Profile Picture" class="img-fluid rounded-circle mb-2" width="128" height="128">
										<?php endif; ?>
									<h5 class="card-title mb-0"><?php echo e(Auth::user()->name); ?></h5>
									<div class="text-muted mb-2 capitalize"><?php echo e(Auth::user()->profile_type); ?></div>

									<div>
										<a class="btn btn-primary btn-sm" href="#">Follow</a>
										<a class="btn btn-primary btn-sm" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-square"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> Message</a>
									</div>
								</div>
                                	<hr class="my-0">
								<div class="card-body">
									<h5 class="h6 card-title">About Me</h5>
                                     <?php if($profileDetails && $profileDetails->about): ?>
											<p><?php echo e($profileDetails->about); ?></p>
											<?php else: ?>
											<p>You haven't added about you.</p>
									<?php endif; ?>
								</div>
								<hr class="my-0">
								<div class="card-body">
									<h5 class="h6 card-title">My Subjects</h5>
										<div class="subject-links">
											<?php if($profileDetails && $profileDetails->user_subjects): ?>
												<?php $__currentLoopData = explode(',', $profileDetails->user_subjects); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<a href="#" class="badge bg-primary me-1 my-1"><?php echo e($subject); ?></a>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<p>You haven't added any subjects.</p>
											<?php endif; ?>
										</div>
								</div>
                                	<hr class="my-0">
								<div class="card-body">
									<h5 class="h6 card-title">Favorites Topics</h5>
										<div class="favorite-topic-links">
											<?php if($profileDetails && $profileDetails->favorite_topics): ?>
												<?php $__currentLoopData = explode(',', $profileDetails->favorite_topics); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<a href="#" class="badge bg-primary me-1 my-1"><?php echo e($topic); ?></a>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<p>You haven't added any favorite topics.</p>
											<?php endif; ?>
										</div>
								</div>
								<hr class="my-0">
								<div class="card-body">
									<h5 class="h6 card-title">Find me on</h5>
									<ul class="list-unstyled mb-0">
										<?php if($profileDetails->socials): ?>
											<?php $__currentLoopData = $profileDetails->socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li class="mb-1"><a target="_blank" href="<?php echo e($link); ?>"><?php echo e(ucfirst($platform)); ?></a></li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<li class="mb-1">No social media profiles found.</li>
										<?php endif; ?>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-md-7 col-xl-7">
						   
						   <div class="card" id="activityFeed">
								<div class="card-header d-flex justify-content-between align-items-center">
									<h5 class="card-title mb-0">Activities</h5>
									<button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#createPost">Create Post</button>
								</div>
								<div class="card-body h-100">
									<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="d-flex align-items-start">
											<?php if($user->profile_picture): ?>
												<img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" alt="Profile Picture" class="rounded-circle me-2" width="36" height="36">
											<?php else: ?>
												<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" class="rounded-circle me-2" width="36" height="36">
											<?php endif; ?>
											<div class="flex-grow-1">
												<small class="float-end text-navy"><?php echo e($post->created_at->diffForHumans()); ?></small>
												<strong><?php echo e($post->user->name); ?></strong><br>
												<p><?php echo e($post->content); ?></p>
												<a href="#" class="btn btn-sm btn-secondary mt-1"><i class="feather-sm" data-feather="heart"></i> Like</a> 
												<a href="#" class="btn btn-sm btn-secondary mt-1"><i class="feather-sm" data-feather="message-square"></i> Comment</a>
												<a href="#" class="btn btn-sm btn-secondary mt-1"><i class="feather-sm" data-feather="share"></i> Share</a>
												<br>
												<small class="text-muted"><?php echo e($post->created_at->format('M d, Y h:i A')); ?></small>
												<hr>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
									<!-- Modal -->
										<div class="modal fade" id="createPost" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title" id="createPostLabel">Create Post</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
													</div>
													<div class="modal-body">
														<form id="createPostForm">
															<?php echo csrf_field(); ?>
															<div class="mb-3">
																<label for="postContent" class="form-label">Post Content</label>
																<textarea class="form-control" id="postContent" name="content" rows="7" placeholder="Enter your post content"></textarea>
															</div>
														</form>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
														<button type="button" class="btn btn-primary" id="submitPostBtn">Create</button>
													</div>
												</div>
											</div>
										</div>
									</div>
							</div>
					</div>
			</main>
				<script>
					const postStoreRoute = "<?php echo e(route('posts.store')); ?>";
				</script>
	  				
	  	<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/profile.blade.php ENDPATH**/ ?>