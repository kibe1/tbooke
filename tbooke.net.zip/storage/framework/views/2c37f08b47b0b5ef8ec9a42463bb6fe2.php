<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main">
			
        	<?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
				<main class="content">		
					<!-- Success Modal -->
						<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true"  data-bs-keyboard="true">
							<div class="modal-dialog modal-sm modal-dialog-centered position-absolute end-0">
								<div class="modal-content bg-white">
									<div class="modal-header border-0">
										<h5 class="modal-title text-success" id="successModalLabel">
											Post created successfully
										</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									</div>
								</div>
							</div>
						</div>

				<div class="container-fluid p-0">
				<div class="mb-3">
					    <div class="row mb-3">
						  <div class="col-md-6 justify-content-between align-items-center">
						  					<?php if($user->profile_picture): ?>
												<img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" alt="Profile Picture" alt="Profile Picture" class="avatar rounded-circle me-2">
											<?php else: ?>
												<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" alt="Profile Picture" class="avatar rounded-circle me-2">
											<?php endif; ?>
								<button type="button" class="btn btn-secondary timeline-create-post" data-bs-toggle="modal" data-bs-target="#createPost">Write something interesting</button>
						  </div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-xl-12">
						   <div class="card" id="activityFeed">
								<div class="card-body h-100">
									<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="d-flex align-items-start post-box">
											<?php if($post->user->profile_picture): ?>
													<img src="<?php echo e(asset('storage/' . $post->user->profile_picture)); ?>" alt="Profile Picture" class="rounded-circle me-2" width="36" height="36">
												<?php else: ?>
													<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" class="rounded-circle me-2" width="36" height="36">
											<?php endif; ?>
											<div class="flex-grow-1">
												<small class="float-end text-navy"><?php echo e($post->created_at->diffForHumans()); ?></small>
												<strong><?php echo e($post->user->name); ?></strong><br>
												<p><?php echo e($post->content); ?></p>
						
												<a href="#" class="btn btn-sm btn-secondary mt-1"><span class="d-none d-md-inline"><i class="feather-sm" data-feather="heart"></i> Like</span><span class="d-inline d-md-none"><i class="feather-sm" data-feather="heart"></i></span></a>
												<a class="btn btn-sm btn-secondary mt-1 comment-toggle-btn"><span class="d-none d-md-inline"><i class="feather-sm" data-feather="message-square"></i> Comment</span><span class="d-inline d-md-none"><i class="feather-sm" data-feather="message-square"></i></span></a>
												<a href="#" class="btn btn-sm btn-secondary mt-1"><span class="d-none d-md-inline"><i class="feather-sm" data-feather="share"></i> Repost</span><span class="d-inline d-md-none"><i class="feather-sm" data-feather="share"></i></span></a>

													<div class="comment-stats float-end">
														 <?php if($post->comments->count() > 0): ?>
															<a class="text-muted comment-toggle-btn" href="#"><?php echo e($post->comments->count()); ?> Comments</a>
														<?php endif; ?>
													</div>
												<br>
													<div class="card-body comment-box">
															<form id="createCommentForm<?php echo e($post->id); ?>">
															<?php echo csrf_field(); ?>
															<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
															<div class="mb-3">
																<textarea class="form-control comment-area" name="content" id="commentContent<?php echo e($post->id); ?>" rows="2" placeholder="Post your comment"></textarea>
															</div>
														</form>
														<button type="button" id="submitCommentBtn<?php echo e($post->id); ?>" class="btn btn-primary submit-comment-btn">Submit</button>
														 	<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<div class="comment-item d-flex align-items-start mt-1">
																	<a class="" href="#">
																		<?php if($comment->user->profile_picture): ?>
																			<img src="<?php echo e(asset('storage/' . $comment->user->profile_picture)); ?>" alt="<?php echo e($comment->user->name); ?>'s Profile Picture" class="rounded-circle me-2" width="36" height="36">
																		<?php else: ?>
																			<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" class="rounded-circle me-2" width="36" height="36">
																		<?php endif; ?>	
																	</a>
																	<div class="flex-grow-1 comment-item-inner-box">
																		<small class="float-end text-navy"><?php echo e($comment->created_at->diffForHumans()); ?></small>
																		<div class="text-muted p-2 mt-1">
																			<strong><?php echo e($comment->user->name); ?></strong> <br>	<?php echo e($comment->content); ?>

																		</div>
																	</div>
																</div>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
									<!-- Modal -->
										<div class="modal fade" id="createPost" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title" id="createPostLabel">Create Post</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
													</div>
													<div class="modal-body">
														<form id="createPostForm">
															<?php echo csrf_field(); ?>
															<div class="mb-3">
																<label for="postContent" class="form-label">Post Content</label>
																<textarea class="form-control" id="postContent" name="content" rows="7" placeholder="Enter your post content"></textarea>
															</div>
														</form>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
														<button type="button" class="btn btn-primary" id="submitPostBtn">Create</button>
													</div>
												</div>
											</div>
										</div>
									</div>
							</div>
					</div>
			</main>
				<script>
					const postStoreRoute = "<?php echo e(route('posts.store')); ?>";
					const commentStoreRoute = "<?php echo e(route('comment.store')); ?>";
				</script>
	  				
	  	<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/feed.blade.php ENDPATH**/ ?>