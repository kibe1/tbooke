<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
	<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	
	<div class="main">
        <?php echo $__env->make('includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
			<main class="content">
				<div class="container-fluid p-0">
					<h1 class="h3 mb-3">Edit Profile</h1>

					<div class="row">
					
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-body text-center">
									<form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" id="profile_form" >
									<?php echo csrf_field(); ?>
									<?php echo method_field('post'); ?>
											<?php if($user->profile_picture): ?>
												<img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" alt="Profile Picture" class="img-fluid rounded-circle mb-2" width="128" height="128">
											<?php else: ?>
												<img src="<?php echo e(asset('/default-images/avatar.png')); ?>" alt="Default Profile Picture" class="img-fluid rounded-circle mb-2" width="128" height="128">
											<?php endif; ?>
										<!-- Profile Picture Input -->
										<div class="mb-3">
											<label for="profile_picture" class="form-label">Profile Picture</label>
											<input id="profile_picture" name="profile_picture" type="file" class="form-control mb-3">
										</div>
										<div class="row">
											<div class="col-md-6">
												<input value="<?php echo e(Auth::user()->first_name); ?>" name="first_name" type="text" class="form-control mb-3" />
											</div>
											<div class="col-md-6">
												<input value="<?php echo e(Auth::user()->surname); ?>" name="surname" type="text" class="form-control mb-3" />
											</div>
										</div>
											<div class="row">
												<div class="col-md-6">
													<input value="<?php echo e(Auth::user()->profile_type); ?>" type="text" class="form-control mb-3 capitalize" disabled />
												</div>
												<div class="col-md-6">
													<input value="<?php echo e(Auth::user()->email); ?>" name="email" type="text" class="form-control mb-2" />
												</div>
											</div>
									</div>
								</div>
								<div class="card-body">
								</div>
							</div>
						</div>

						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<h5 class="h6 card-title">About Me</h5>
								</div>
								<div class="card-body">
									<textarea class="form-control" name="about" rows="4" cols="5" placeholder="Tell us more about yourself"><?php echo e($profileDetails->about ?? ''); ?></textarea>
								</div>
							</div>

							<div class="card">
								<div class="card-header">
									<h5 class="h6 card-title">My Subjects</h5>
								</div>
								<div class="about-card-inner">
									<select name="user_subjects[]" data-placeholder="Select your subjects" multiple class="chosen-select-width form-select" tabindex="16">
										<option value="Geography" <?php if(in_array('Geography', $userSubjects)): ?> selected <?php endif; ?>>Geography</option>
										<option value="Mathematics" <?php if(in_array('Mathematics', $userSubjects)): ?> selected <?php endif; ?>>Mathematics</option>
										<option value="Business" <?php if(in_array('Business', $userSubjects)): ?> selected <?php endif; ?>>Business</option>
										<option value="Kiswahili" <?php if(in_array('Kiswahili', $userSubjects)): ?> selected <?php endif; ?>>Kiswahili</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					
				<div class="row">
						
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<h5 class="h6 card-title">Favorite Topics</h5>
								</div>
								<div class="about-card-inner">
									<select name="favorite_topics[]" data-placeholder="Select your favorite topics" multiple class="chosen-select-width form-select" tabindex="16">
											<option value="Algebra" <?php if(in_array('Algebra', $favoriteTopics)): ?> selected <?php endif; ?>>Algebra</option>
    										<option value="Calculus" <?php if(in_array('Calculus', $favoriteTopics)): ?> selected <?php endif; ?>>Calculus</option>
    										<option value="Marketing" <?php if(in_array('Marketing', $favoriteTopics)): ?> selected <?php endif; ?>>Marketing</option>
    										<option value="Insurance" <?php if(in_array('Insurance', $favoriteTopics)): ?> selected <?php endif; ?>>Insurance</option>
									</select>
								</div>
							</div>
						</div>
						
					<div class="col-md-6">
						<div style="padding-bottom: 18px;" class="card">
							<div class="card-header">
								<h5 class="h6 card-title">Social Media</h5>
							</div>
							<div class="card-body row align-items-center card-body-forms">
								<label for="facebookInput" class="col-sm-3 col-form-label">Facebook:</label>
								<div class="col-sm-9">
									<input type="text" id="facebookInput" name="socials[facebook]" class="form-control" placeholder="Enter your Facebook profile" value="<?php echo e($profileDetails->socials['facebook'] ?? ''); ?>">
								</div>
							</div>
							<div class="card-body row align-items-center card-body-forms">
								<label for="twitterInput" class="col-sm-3 col-form-label">Twitter:</label>
								<div class="col-sm-9">
									<input type="text" id="twitterInput" name="socials[twitter]" class="form-control" placeholder="Enter your Twitter profile" value="<?php echo e($profileDetails->socials['twitter'] ?? ''); ?>">
								</div>
							</div>
						</div>
					</div>
				</div>	
				
					<div class="row">
    					<div class="col-md-12 d-flex justify-content-end align-items-center">
        				<input type="submit" class="btn btn-primary" id="submit_form" value="Save Profile" />
    				</div>
				</div>
				</form>
			</div>
		</main>
        
	  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<?php /**PATH C:\Users\USER\Desktop\tbooke.net\resources\views/profile/edit-profile.blade.php ENDPATH**/ ?>