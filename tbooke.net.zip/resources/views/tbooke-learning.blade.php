@include('includes.header')
{{-- Sidebar --}}
@include('includes.sidebar')
@include('sweetalert::alert')

{{-- Topbar --}}
<div class="main">
    @include('includes.topbar')
    {{-- Main Content --}}
    <main class="content">
        <div class="container-fluid p-0">

					<div class="mb-3">
						<div class="row mb-3">
							<div class="col-md-6 d-flex justify-content-start align-items-center">
								<h1 class="h3 d-inline align-middle">Tbooke Learning</h1>
							</div>
						@if ($userIsCreator)
							<div class="col-md-6 d-flex justify-content-end align-items-center">
								<a type="button" href="{{ route('tbooke-learning.create') }}" class="btn btn-tbooke mb-2 mb-md-0 me-md-2 tbooke-create-btn">Create</a>
							</div> 
						@endif
						</div>
					</div>

						<div class="row content">
							@foreach($contents as $content)
								<div class="col-12 col-md-4">
									<div class="card">
										<img class="card-img-top content-thumbnail" src="{{ asset('storage/' . $content->content_thumbnail) }}" alt="">
										<div class="card-header author-category">
											<h5 class="card-title author">{{ $content->user->first_name }} {{ $content->user->surname }}</h5>
											<h5 class="card-title content-title">{{ $content->content_title }}</h5>
											<div class="content-categories">
												@foreach(explode(',', $content->content_category) as $category)
													<a href="#" class="badge bg-primary me-1 my-1">{{ $category }}</a>
												@endforeach
											</div>
										</div>
										<div class="card-body tbooke-content">
											<p class="card-text content-desc">{{ Str::limit(strip_tags($content->content), 66) }}</p>
											<a href="#" class="card-link read-more-link">Read More</a>
										</div>
									</div>
								</div>
							@endforeach
						</div>

		</div>
    </main>
    {{-- footer --}}
    @include('includes.footer')
</div>
