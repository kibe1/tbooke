	<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="#" target="_blank"><strong>Tbooke</strong></a> - <a class="text-muted" href="#" target="_blank"><strong>Copyright 2024</strong></a>								&copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
	</footer>
</div>
	<script src="/docsupport/jquery-3.2.1.min.js" type="text/javascript"></script>
	<script src="/docsupport/chosen.jquery.js" type="text/javascript"></script>
	<script src="/docsupport/prism.js" type="text/javascript" charset="utf-8"></script>
	<script src="/docsupport/init.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://cdn.tiny.cloud/1/omzlvo1v34uqcwchvwg1su29904hdb86emi5sr5agotnloym/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
	<script src="{{ asset('/js/custom.js') }}"></script>
	<script src="{{ asset('/static/js/app.js') }}"></script>
</body>
</html>